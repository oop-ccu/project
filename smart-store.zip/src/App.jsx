import { useState, useEffect, useRef } from "react";

const FONT_STYLES = `
@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600&family=DM+Mono:wght@400;500&family=Outfit:wght@300;400;500;600&display=swap');
`;

const CSS = `
* { box-sizing: border-box; margin: 0; padding: 0; }
body { background: #0a0a0a; color: #e8e4dc; font-family: 'Outfit', sans-serif; }
:root {
  --bg: #0a0a0a;
  --bg2: #121212;
  --bg3: #1a1a1a;
  --bg4: #222;
  --text: #e8e4dc;
  --muted: #888;
  --border: rgba(255,255,255,0.08);
  --gold: #c9a96e;
  --gold2: #e8c98a;
  --red: #d94f4f;
  --green: #4caf7d;
  --r: 6px;
}
.serif { font-family: 'Cormorant Garamond', serif; }
.mono { font-family: 'DM Mono', monospace; }

/* NAV */
.nav { position: sticky; top:0; z-index:100; background: rgba(10,10,10,0.95); border-bottom: 1px solid var(--border); backdrop-filter: blur(12px); padding: 0 40px; display:flex; align-items:center; justify-content:space-between; height:64px; }
.nav-logo { font-family:'Cormorant Garamond',serif; font-size:22px; font-weight:600; letter-spacing:3px; color:var(--gold); cursor:pointer; }
.nav-links { display:flex; gap:32px; }
.nav-link { font-size:12px; letter-spacing:2px; text-transform:uppercase; color:var(--muted); cursor:pointer; transition:color 0.2s; padding:4px 0; border-bottom:1px solid transparent; }
.nav-link:hover, .nav-link.active { color:var(--text); border-bottom-color:var(--gold); }
.nav-actions { display:flex; gap:16px; align-items:center; }
.nav-btn { font-size:11px; letter-spacing:1.5px; text-transform:uppercase; cursor:pointer; background:none; border:none; color:var(--muted); transition:color 0.2s; }
.nav-btn:hover { color:var(--text); }
.cart-badge { background:var(--gold); color:#0a0a0a; border-radius:50%; width:18px; height:18px; font-size:10px; display:inline-flex; align-items:center; justify-content:center; font-weight:600; margin-left:4px; }

/* HERO */
.hero { min-height: 90vh; display:flex; flex-direction:column; align-items:center; justify-content:center; position:relative; overflow:hidden; text-align:center; padding: 40px; }
.hero-bg { position:absolute; inset:0; background: radial-gradient(ellipse at 50% 100%, rgba(201,169,110,0.08) 0%, transparent 60%), linear-gradient(180deg, #0a0a0a 0%, #111 50%, #0a0a0a 100%); }
.hero-grid { position:absolute; inset:0; background-image: linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px); background-size: 60px 60px; opacity:0.4; }
.hero-content { position:relative; z-index:1; }
.hero-eyebrow { font-size:11px; letter-spacing:5px; text-transform:uppercase; color:var(--gold); margin-bottom:24px; }
.hero-title { font-family:'Cormorant Garamond',serif; font-size:clamp(60px,10vw,120px); font-weight:400; line-height:0.9; letter-spacing:-2px; margin-bottom:32px; }
.hero-subtitle { font-size:14px; letter-spacing:2px; color:var(--muted); margin-bottom:48px; max-width:400px; margin-left:auto; margin-right:auto; line-height:1.8; }
.hero-cta { display:inline-flex; gap:16px; flex-wrap:wrap; justify-content:center; }
.btn-primary { background:var(--gold); color:#0a0a0a; font-family:'Outfit',sans-serif; font-size:11px; letter-spacing:2px; text-transform:uppercase; padding:14px 32px; border:none; cursor:pointer; transition:background 0.2s,transform 0.1s; font-weight:600; }
.btn-primary:hover { background:var(--gold2); }
.btn-outline { background:none; color:var(--text); font-family:'Outfit',sans-serif; font-size:11px; letter-spacing:2px; text-transform:uppercase; padding:14px 32px; border:1px solid var(--border); cursor:pointer; transition:border-color 0.2s; }
.btn-outline:hover { border-color:var(--gold); color:var(--gold); }

/* SECTIONS */
.section { padding: 80px 40px; max-width: 1280px; margin: 0 auto; }
.section-title { font-family:'Cormorant Garamond',serif; font-size:48px; font-weight:400; margin-bottom:8px; }
.section-sub { font-size:12px; letter-spacing:3px; text-transform:uppercase; color:var(--muted); margin-bottom:48px; }

/* PRODUCT GRID */
.product-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(240px,1fr)); gap:2px; }
.product-card { background:var(--bg2); position:relative; cursor:pointer; transition:background 0.2s; overflow:hidden; }
.product-card:hover { background:var(--bg3); }
.product-card:hover .product-overlay { opacity:1; }
.product-img { width:100%; aspect-ratio:3/4; display:flex; align-items:center; justify-content:center; background:var(--bg3); font-size:48px; position:relative; overflow:hidden; }
.product-overlay { position:absolute; inset:0; background:rgba(201,169,110,0.1); display:flex; align-items:center; justify-content:center; opacity:0; transition:opacity 0.2s; }
.product-overlay-btn { background:var(--gold); color:#0a0a0a; font-size:11px; letter-spacing:2px; text-transform:uppercase; padding:12px 24px; font-weight:600; border:none; cursor:pointer; }
.product-info { padding: 16px; }
.product-name { font-size:14px; margin-bottom:4px; font-weight:400; }
.product-price { font-family:'DM Mono',monospace; font-size:13px; color:var(--gold); }
.product-stock { font-size:11px; color:var(--muted); margin-top:4px; }
.badge-low { color:var(--red); }
.badge-cat { font-size:10px; letter-spacing:1.5px; text-transform:uppercase; color:var(--muted); margin-bottom:6px; }

/* SIDEBAR / PANEL */
.panel { background:var(--bg2); border-left:1px solid var(--border); width:420px; position:fixed; right:0; top:0; bottom:0; z-index:200; overflow-y:auto; transform:translateX(100%); transition:transform 0.35s cubic-bezier(0.4,0,0.2,1); padding:32px; }
.panel.open { transform:translateX(0); }
.panel-overlay { position:fixed; inset:0; background:rgba(0,0,0,0.6); z-index:199; opacity:0; pointer-events:none; transition:opacity 0.35s; }
.panel-overlay.open { opacity:1; pointer-events:all; }
.panel-title { font-family:'Cormorant Garamond',serif; font-size:28px; margin-bottom:32px; }
.panel-close { position:absolute; top:24px; right:24px; background:none; border:none; color:var(--muted); cursor:pointer; font-size:24px; }

/* FORM */
.form-group { margin-bottom:20px; }
.form-label { font-size:11px; letter-spacing:2px; text-transform:uppercase; color:var(--muted); display:block; margin-bottom:8px; }
.form-input { width:100%; background:var(--bg3); border:1px solid var(--border); color:var(--text); padding:12px 16px; font-family:'Outfit',sans-serif; font-size:14px; outline:none; transition:border-color 0.2s; border-radius:var(--r); }
.form-input:focus { border-color:var(--gold); }
.form-select { width:100%; background:var(--bg3); border:1px solid var(--border); color:var(--text); padding:12px 16px; font-family:'Outfit',sans-serif; font-size:14px; outline:none; border-radius:var(--r); }
.form-row { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
.msg { padding:12px 16px; border-radius:var(--r); font-size:13px; margin-bottom:16px; }
.msg.success { background:rgba(76,175,125,0.12); border:1px solid rgba(76,175,125,0.3); color:var(--green); }
.msg.error { background:rgba(217,79,79,0.12); border:1px solid rgba(217,79,79,0.3); color:var(--red); }

/* CART */
.cart-item { display:flex; gap:16px; padding:20px 0; border-bottom:1px solid var(--border); align-items:flex-start; }
.cart-item-icon { width:60px; height:60px; background:var(--bg3); display:flex; align-items:center; justify-content:center; font-size:24px; flex-shrink:0; border-radius:var(--r); }
.cart-item-info { flex:1; }
.cart-item-name { font-size:14px; margin-bottom:4px; }
.cart-item-price { font-family:'DM Mono',monospace; font-size:12px; color:var(--gold); }
.cart-remove { background:none; border:none; color:var(--muted); cursor:pointer; font-size:18px; }
.cart-remove:hover { color:var(--red); }
.cart-total { padding:20px 0; display:flex; justify-content:space-between; align-items:center; border-top:1px solid var(--border); margin-top:8px; }
.cart-total-label { font-size:12px; letter-spacing:2px; text-transform:uppercase; color:var(--muted); }
.cart-total-amount { font-family:'DM Mono',monospace; font-size:20px; color:var(--gold); }

/* DASHBOARD */
.dash { display:grid; grid-template-columns:240px 1fr; min-height:100vh; }
.dash-sidebar { background:var(--bg2); border-right:1px solid var(--border); padding:32px 0; }
.dash-logo { font-family:'Cormorant Garamond',serif; font-size:18px; font-weight:600; color:var(--gold); padding:0 24px 32px; letter-spacing:2px; }
.dash-menu-item { padding:12px 24px; font-size:13px; letter-spacing:1px; cursor:pointer; transition:background 0.15s; display:flex; align-items:center; gap:12px; color:var(--muted); }
.dash-menu-item:hover { background:var(--bg3); color:var(--text); }
.dash-menu-item.active { background:var(--bg3); color:var(--gold); border-right:2px solid var(--gold); }
.dash-menu-section { font-size:10px; letter-spacing:2px; text-transform:uppercase; color:rgba(136,136,136,0.5); padding:24px 24px 8px; }
.dash-content { padding:40px; background:var(--bg); }
.dash-header { margin-bottom:40px; }
.dash-title { font-family:'Cormorant Garamond',serif; font-size:36px; margin-bottom:4px; }
.dash-sub { font-size:13px; color:var(--muted); }

/* METRIC CARDS */
.metrics { display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:16px; margin-bottom:40px; }
.metric { background:var(--bg2); border:1px solid var(--border); border-radius:var(--r); padding:20px; }
.metric-label { font-size:11px; letter-spacing:2px; text-transform:uppercase; color:var(--muted); margin-bottom:8px; }
.metric-value { font-family:'DM Mono',monospace; font-size:28px; color:var(--gold); }
.metric-sub { font-size:12px; color:var(--muted); margin-top:4px; }

/* TRANSACTION TABLE */
.table-wrap { overflow-x:auto; }
table { width:100%; border-collapse:collapse; font-size:13px; }
th { text-align:left; font-size:10px; letter-spacing:2px; text-transform:uppercase; color:var(--muted); padding:12px 16px; border-bottom:1px solid var(--border); }
td { padding:14px 16px; border-bottom:1px solid var(--border); vertical-align:top; }
tr:hover td { background:var(--bg2); }
.tag { display:inline-block; font-size:10px; letter-spacing:1px; text-transform:uppercase; padding:3px 10px; border-radius:2px; }
.tag.revenue { background:rgba(76,175,125,0.15); color:var(--green); }
.tag.expense { background:rgba(217,79,79,0.12); color:var(--red); }

/* TABS */
.tabs { display:flex; gap:0; border-bottom:1px solid var(--border); margin-bottom:32px; }
.tab { font-size:12px; letter-spacing:2px; text-transform:uppercase; padding:12px 24px; cursor:pointer; color:var(--muted); border-bottom:2px solid transparent; transition:all 0.2s; }
.tab.active { color:var(--gold); border-bottom-color:var(--gold); }

/* ROLE SWITCHER */
.role-switcher { position:fixed; bottom:24px; left:50%; transform:translateX(-50%); background:var(--bg2); border:1px solid var(--border); border-radius:40px; display:flex; gap:0; padding:4px; z-index:300; box-shadow:0 8px 32px rgba(0,0,0,0.4); }
.role-btn { font-size:11px; letter-spacing:1.5px; text-transform:uppercase; padding:10px 20px; border:none; background:none; color:var(--muted); cursor:pointer; border-radius:40px; transition:all 0.2s; }
.role-btn.active { background:var(--gold); color:#0a0a0a; font-weight:600; }

/* MEMBER BADGE */
.member-banner { background:linear-gradient(135deg,rgba(201,169,110,0.1),rgba(201,169,110,0.05)); border:1px solid rgba(201,169,110,0.2); border-radius:var(--r); padding:16px 20px; margin-bottom:24px; display:flex; align-items:center; justify-content:space-between; }
.member-name { font-size:14px; font-weight:500; }
.member-level { font-size:10px; letter-spacing:2px; text-transform:uppercase; color:var(--gold); }
.member-pts { font-family:'DM Mono',monospace; font-size:12px; color:var(--muted); }

/* ITEM ICONS MAP */
.icon-cell { text-align:center; font-size:32px; }

/* LOGIN PAGE */
.login-page { min-height:100vh; display:flex; align-items:center; justify-content:center; background:var(--bg); position:relative; overflow:hidden; }
.login-bg { position:absolute; inset:0; background:radial-gradient(ellipse at 30% 50%, rgba(201,169,110,0.06) 0%, transparent 60%); }
.login-card { position:relative; background:var(--bg2); border:1px solid var(--border); border-radius:var(--r); padding:48px; width:440px; max-width:calc(100vw - 48px); }
.login-logo { font-family:'Cormorant Garamond',serif; font-size:28px; color:var(--gold); letter-spacing:3px; text-align:center; margin-bottom:8px; }
.login-sub { font-size:12px; letter-spacing:2px; text-transform:uppercase; color:var(--muted); text-align:center; margin-bottom:40px; }
.divider { display:flex; align-items:center; gap:16px; margin:24px 0; color:var(--muted); font-size:12px; }
.divider::before, .divider::after { content:''; flex:1; height:1px; background:var(--border); }

/* ANIMATIONS */
@keyframes fadeUp { from { opacity:0; transform:translateY(20px); } to { opacity:1; transform:translateY(0); } }
.fade-up { animation: fadeUp 0.5s ease both; }
.delay-1 { animation-delay:0.1s; }
.delay-2 { animation-delay:0.2s; }
.delay-3 { animation-delay:0.3s; }

/* CHECKOUT */
.checkout-grid { display:grid; grid-template-columns:1fr 360px; gap:40px; }
.order-summary { background:var(--bg2); border:1px solid var(--border); border-radius:var(--r); padding:28px; position:sticky; top:100px; }
.summary-row { display:flex; justify-content:space-between; align-items:center; padding:10px 0; font-size:13px; border-bottom:1px solid var(--border); }
.summary-row:last-child { border-bottom:none; font-size:16px; color:var(--gold); }
.summary-label { color:var(--muted); }

/* RESPONSIVE */
@media(max-width:768px){
  .nav { padding:0 20px; }
  .hero-title { font-size:60px; }
  .section { padding:60px 20px; }
  .product-grid { grid-template-columns:repeat(auto-fill,minmax(160px,1fr)); }
  .panel { width:100%; }
  .dash { grid-template-columns:1fr; }
  .dash-sidebar { display:none; }
  .checkout-grid { grid-template-columns:1fr; }
}
`;

// ─── SEED DATA ───────────────────────────────────────────────────
const ITEM_ICONS = {
  Electronics: "🔌", Accessories: "🎧", Network: "🌐", Storage: "💾",
  Peripherals: "🖱️", Office: "📎", Bags: "🎒", Apparel: "👕",
  Default: "📦"
};

const INITIAL_INVENTORY = [
  { id:"P001", name:"USB-C Adapter", price:500, stock:20, category:"Electronics" },
  { id:"P002", name:"Network Cable 5m", price:150, stock:50, category:"Network" },
  { id:"P003", name:"High-Speed Router", price:4500, stock:5, category:"Network" },
  { id:"P004", name:"Mechanical Keyboard", price:2800, stock:12, category:"Peripherals" },
  { id:"P005", name:"Ergonomic Mouse", price:1200, stock:18, category:"Peripherals" },
  { id:"P006", name:"Monitor Stand", price:890, stock:8, category:"Accessories" },
  { id:"P007", name:"256GB SSD", price:1600, stock:25, category:"Storage" },
  { id:"P008", name:"Laptop Sleeve 15\"", price:650, stock:30, category:"Bags" },
  { id:"P009", name:"USB Hub 7-Port", price:780, stock:15, category:"Electronics" },
  { id:"P010", name:"Webcam 1080p", price:1350, stock:10, category:"Electronics" },
  { id:"P011", name:"Cable Organizer Kit", price:320, stock:40, category:"Accessories" },
  { id:"P012", name:"Power Strip 6-Outlet", price:560, stock:22, category:"Office" },
];

const INITIAL_MEMBERS = [
  { id:"M001", name:"Alice Chen", email:"alice@demo.com", password:"1234", age:28, gender:"Female", coupon:2, point:150, total_spending:1750, level:"gold" },
  { id:"M002", name:"Bob Wang", email:"bob@demo.com", password:"1234", age:32, gender:"Male", coupon:0, point:45, total_spending:4500, level:"silver" },
  { id:"M003", name:"Carol Liu", email:"carol@demo.com", password:"1234", age:25, gender:"Female", coupon:5, point:820, total_spending:12000, level:"vip" },
];

const INITIAL_TRANSACTIONS = [
  { id:"T0001", type:"expense", amount:-20000, description:"Monthly Store Rent", date:"2026-04-01 09:00:00" },
  { id:"T0002", type:"expense", amount:-3500, description:"Electricity and Water Bill", date:"2026-04-01 09:05:00" },
  { id:"T0003", type:"expense", amount:-12000, description:"Store Management Tablet", date:"2026-04-02 10:00:00" },
  { id:"T0004", type:"checkout revenue", amount:1750, description:"", items:[{name:"USB-C Adapter",qty:2,price:500},{name:"Network Cable",qty:5,price:150}], member_id:"M001", date:"2026-05-09 14:22:00" },
  { id:"T0005", type:"checkout revenue", amount:4500, description:"", items:[{name:"High-Speed Router",qty:1,price:4500}], member_id:"M002", date:"2026-05-09 16:45:00" },
  { id:"T0006", type:"expense", amount:-32000, description:"Personnel Cost - Worker W001 Salary", date:"2026-05-01 09:00:00" },
];

const INITIAL_SALARIES = [
  { worker_id:"W001", worker_name:"David Lin", worker_role:"Cashier", base_salary:32000, hours_worked:160, bonus:2000, deductions:0 },
  { worker_id:"W002", worker_name:"Emma Huang", worker_role:"Manager", base_salary:45000, hours_worked:176, bonus:5000, deductions:0 },
  { worker_id:"W003", worker_name:"Frank Wu", worker_role:"Stock Staff", base_salary:28000, hours_worked:144, bonus:0, deductions:500 },
];

const DISCOUNT_RATES = { bronze:1.0, silver:0.95, gold:0.90, vip:0.85 };
const LEVEL_COLORS = { bronze:"#cd7f32", silver:"#aaa", gold:"#c9a96e", vip:"#9b59b6" };

function calcBalance(transactions) {
  return transactions.reduce((sum, t) => sum + t.amount, 0);
}

function getIcon(category) {
  return ITEM_ICONS[category] || ITEM_ICONS.Default;
}

// ─── COMPONENTS ────────────────────────────────────────────────

function Notification({ msg }) {
  if (!msg) return null;
  return <div className={`msg ${msg.type}`}>{msg.text}</div>;
}

function ProductCard({ item, onAdd }) {
  const icon = getIcon(item.category);
  const lowStock = item.stock <= 5;
  return (
    <div className="product-card" onClick={() => onAdd(item)}>
      <div className="product-img">
        <span style={{fontSize:56}}>{icon}</span>
        <div className="product-overlay">
          <button className="product-overlay-btn">Add to Cart</button>
        </div>
      </div>
      <div className="product-info">
        <div className="badge-cat">{item.category}</div>
        <div className="product-name">{item.name}</div>
        <div className="product-price">NT$ {item.price.toLocaleString()}</div>
        <div className={`product-stock ${lowStock ? "badge-low" : ""}`}>
          {item.stock === 0 ? "Out of Stock" : lowStock ? `Only ${item.stock} left` : `In Stock (${item.stock})`}
        </div>
      </div>
    </div>
  );
}

function CartPanel({ cart, setCart, member, onCheckout, open, onClose, inventory }) {
  const subtotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const rate = member ? (DISCOUNT_RATES[member.level] || 1) : 1;
  const total = Math.round(subtotal * rate);

  function remove(id) { setCart(cart.filter(i => i.id !== id)); }
  function changeQty(id, delta) {
    setCart(cart.map(i => {
      if (i.id !== id) return i;
      const inv = inventory.find(p => p.id === id);
      const newQty = Math.max(1, Math.min(i.qty + delta, inv ? inv.stock : 99));
      return { ...i, qty: newQty };
    }));
  }

  return (
    <>
      <div className={`panel-overlay ${open ? "open" : ""}`} onClick={onClose} />
      <div className={`panel ${open ? "open" : ""}`}>
        <button className="panel-close" onClick={onClose}>×</button>
        <div className="panel-title serif">Shopping Cart</div>

        {cart.length === 0 ? (
          <p style={{color:"var(--muted)",fontSize:14}}>Your cart is empty.</p>
        ) : (
          <>
            {member && (
              <div style={{padding:"10px 14px",background:"rgba(201,169,110,0.08)",borderRadius:"var(--r)",marginBottom:20,fontSize:13}}>
                <span style={{color:"var(--gold)"}}>♦ {member.level.toUpperCase()} discount applied: {Math.round((1-rate)*100)}% off</span>
              </div>
            )}
            {cart.map(item => (
              <div className="cart-item" key={item.id}>
                <div className="cart-item-icon">{getIcon(item.category)}</div>
                <div className="cart-item-info">
                  <div className="cart-item-name">{item.name}</div>
                  <div className="cart-item-price">NT$ {item.price.toLocaleString()} ea.</div>
                  <div style={{display:"flex",gap:8,alignItems:"center",marginTop:8}}>
                    <button onClick={()=>changeQty(item.id,-1)} style={{background:"var(--bg3)",border:"1px solid var(--border)",color:"var(--text)",width:28,height:28,cursor:"pointer",borderRadius:4}}>−</button>
                    <span style={{fontFamily:"DM Mono,monospace",fontSize:14,minWidth:20,textAlign:"center"}}>{item.qty}</span>
                    <button onClick={()=>changeQty(item.id,1)} style={{background:"var(--bg3)",border:"1px solid var(--border)",color:"var(--text)",width:28,height:28,cursor:"pointer",borderRadius:4}}>+</button>
                  </div>
                </div>
                <button className="cart-remove" onClick={()=>remove(item.id)}>×</button>
              </div>
            ))}
            <div className="cart-total">
              <div>
                <div className="cart-total-label">Total</div>
                {rate < 1 && <div style={{fontSize:12,color:"var(--muted)",textDecoration:"line-through"}}>NT$ {subtotal.toLocaleString()}</div>}
              </div>
              <div className="cart-total-amount">NT$ {total.toLocaleString()}</div>
            </div>
            <button className="btn-primary" style={{width:"100%",marginTop:16}} onClick={()=>onCheckout(total,subtotal)}>
              Proceed to Checkout
            </button>
          </>
        )}
      </div>
    </>
  );
}

// ─── CUSTOMER VIEW ─────────────────────────────────────────────

function CustomerView({ members, setMembers, inventory, setInventory, transactions, setTransactions }) {
  const [page, setPage] = useState("shop");
  const [cart, setCart] = useState([]);
  const [currentMember, setCurrentMember] = useState(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPw, setLoginPw] = useState("");
  const [msg, setMsg] = useState(null);
  const [regForm, setRegForm] = useState({ name:"", email:"", password:"", confirm:"", age:"", gender:"Female" });
  const [searchQ, setSearchQ] = useState("");
  const [catFilter, setCatFilter] = useState("All");
  const [payInput, setPayInput] = useState("");
  const [checkoutTotal, setCheckoutTotal] = useState(0);
  const [checkoutSub, setCheckoutSub] = useState(0);

  const categories = ["All", ...Array.from(new Set(inventory.map(i => i.category)))];
  const filtered = inventory.filter(i =>
    (catFilter === "All" || i.category === catFilter) &&
    i.name.toLowerCase().includes(searchQ.toLowerCase()) &&
    i.stock > 0
  );

  function addToCart(item) {
    if (item.stock === 0) return;
    setCart(prev => {
      const ex = prev.find(c => c.id === item.id);
      if (ex) return prev.map(c => c.id === item.id ? {...c, qty: Math.min(c.qty+1, item.stock)} : c);
      return [...prev, {...item, qty:1}];
    });
    setCartOpen(true);
  }

  function login() {
    const m = members.find(m => m.email === loginEmail && m.password === loginPw);
    if (m) {
      setCurrentMember(m);
      setMsg({type:"success", text:`Welcome back, ${m.name}!`});
      setPage("shop");
    } else {
      setMsg({type:"error", text:"Invalid email or password."});
    }
  }

  function register() {
    if (!regForm.name || !regForm.email || !regForm.password) return setMsg({type:"error",text:"Please fill all required fields."});
    if (regForm.password !== regForm.confirm) return setMsg({type:"error",text:"Passwords do not match."});
    if (members.find(m => m.email === regForm.email)) return setMsg({type:"error",text:"Email already registered."});
    const newM = {
      id: `M${String(members.length+1).padStart(3,"0")}`,
      name:regForm.name, email:regForm.email, password:regForm.password,
      age:parseInt(regForm.age)||0, gender:regForm.gender,
      coupon:0, point:0, total_spending:0, level:"bronze"
    };
    setMembers([...members, newM]);
    setCurrentMember(newM);
    setMsg({type:"success",text:"Account created! Welcome to Smart Store."});
    setTimeout(()=>setPage("shop"),1200);
  }

  function processCheckout(total, sub) {
    const pay = parseFloat(payInput);
    if (!payInput || isNaN(pay) || pay < total) {
      setMsg({type:"error",text:`Payment insufficient. Need NT$ ${total.toLocaleString()}`});
      return;
    }
    // Deduct inventory
    const newInv = inventory.map(item => {
      const cartItem = cart.find(c => c.id === item.id);
      return cartItem ? {...item, stock: item.stock - cartItem.qty} : item;
    });
    // Record transaction
    const record = {
      id: `T${String(transactions.length+1).padStart(4,"0")}`,
      type:"checkout revenue",
      amount: total,
      description:"",
      items: cart.map(c => ({name:c.name, qty:c.qty, price:c.price})),
      member_id: currentMember ? currentMember.id : null,
      date: new Date().toLocaleString("sv-SE").replace("T"," ")
    };
    // Update member points & spending
    if (currentMember) {
      const pts = Math.floor(total / 100);
      setMembers(members.map(m => m.id === currentMember.id
        ? {...m, point: m.point+pts, total_spending: m.total_spending+total}
        : m
      ));
      setCurrentMember(prev => ({...prev, point:prev.point+pts, total_spending:prev.total_spending+total}));
    }
    setInventory(newInv);
    setTransactions([...transactions, record]);
    setCart([]);
    setCartOpen(false);
    setPayInput("");
    setPage("shop");
    setMsg({type:"success",text:`✓ Payment successful! Change: NT$ ${(pay-total).toLocaleString()}`});
    setTimeout(()=>setMsg(null),4000);
  }

  function startCheckout(total, sub) {
    setCheckoutTotal(total);
    setCheckoutSub(sub);
    setCartOpen(false);
    setPage("checkout");
  }

  return (
    <div>
      <style>{FONT_STYLES}{CSS}</style>
      {/* NAV */}
      <nav className="nav">
        <div className="nav-logo" onClick={()=>setPage("shop")}>SMART STORE</div>
        <div className="nav-links">
          <span className={`nav-link ${page==="shop"?"active":""}`} onClick={()=>setPage("shop")}>Shop</span>
          {currentMember && <span className={`nav-link ${page==="profile"?"active":""}`} onClick={()=>setPage("profile")}>My Account</span>}
        </div>
        <div className="nav-actions">
          {currentMember ? (
            <span style={{fontSize:12,color:"var(--gold)"}}>♦ {currentMember.name}</span>
          ) : (
            <>
              <button className="nav-btn" onClick={()=>{setMsg(null);setPage("login")}}>Sign In</button>
              <button className="nav-btn" onClick={()=>{setMsg(null);setPage("register")}}>Register</button>
            </>
          )}
          {currentMember && <button className="nav-btn" onClick={()=>{setCurrentMember(null);setPage("shop")}}>Logout</button>}
          <button className="nav-btn" onClick={()=>setCartOpen(true)}>
            Cart {cart.length > 0 && <span className="cart-badge">{cart.reduce((s,i)=>s+i.qty,0)}</span>}
          </button>
        </div>
      </nav>

      {msg && <div style={{padding:"0 40px"}}><div className={`msg ${msg.type}`} style={{margin:"16px 0"}}>{msg.text}</div></div>}

      {/* PAGES */}
      {page === "shop" && (
        <>
          <div className="hero">
            <div className="hero-bg" />
            <div className="hero-grid" />
            <div className="hero-content fade-up">
              <div className="hero-eyebrow">New Collection — 2026</div>
              <div className="hero-title serif">Smart<br/>Store</div>
              <div className="hero-subtitle">Premium electronics & accessories. Modern living essentials.</div>
              <div className="hero-cta">
                <button className="btn-primary" onClick={()=>document.getElementById("products")?.scrollIntoView({behavior:"smooth"})}>Shop Now</button>
                {!currentMember && <button className="btn-outline" onClick={()=>setPage("register")}>Join Membership</button>}
              </div>
            </div>
          </div>

          <div className="section" id="products">
            {currentMember && (
              <div className="member-banner">
                <div>
                  <div className="member-name">{currentMember.name}</div>
                  <div className="member-level" style={{color:LEVEL_COLORS[currentMember.level]||"var(--gold)"}}>
                    {currentMember.level.toUpperCase()} MEMBER — {Math.round((1-(DISCOUNT_RATES[currentMember.level]||1))*100)}% discount active
                  </div>
                </div>
                <div style={{textAlign:"right"}}>
                  <div className="member-pts">{currentMember.point.toLocaleString()} pts</div>
                  <div style={{fontSize:11,color:"var(--muted)"}}>Total spent: NT${currentMember.total_spending.toLocaleString()}</div>
                </div>
              </div>
            )}
            <div className="section-title serif">Products</div>
            <div className="section-sub">Curated essentials for modern life</div>

            {/* Filters */}
            <div style={{display:"flex",gap:16,flexWrap:"wrap",marginBottom:32,alignItems:"center"}}>
              <input className="form-input" placeholder="Search products..." value={searchQ} onChange={e=>setSearchQ(e.target.value)} style={{maxWidth:260}} />
              <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                {categories.map(c => (
                  <button key={c} onClick={()=>setCatFilter(c)}
                    style={{padding:"6px 16px",fontSize:11,letterSpacing:1.5,textTransform:"uppercase",background:catFilter===c?"var(--gold)":"var(--bg3)",color:catFilter===c?"#0a0a0a":"var(--muted)",border:"none",cursor:"pointer",borderRadius:"var(--r)",transition:"all 0.2s"}}>
                    {c}
                  </button>
                ))}
              </div>
            </div>

            <div className="product-grid">
              {filtered.map(item => <ProductCard key={item.id} item={item} onAdd={addToCart} />)}
            </div>
          </div>
        </>
      )}

      {page === "login" && (
        <div className="login-page">
          <div className="login-bg" />
          <div className="login-card fade-up">
            <div className="login-logo">SMART STORE</div>
            <div className="login-sub">Member Sign In</div>
            <Notification msg={msg} />
            <div className="form-group">
              <label className="form-label">Email</label>
              <input className="form-input" type="email" placeholder="your@email.com" value={loginEmail} onChange={e=>setLoginEmail(e.target.value)} />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input className="form-input" type="password" placeholder="••••••••" value={loginPw} onChange={e=>setLoginPw(e.target.value)} onKeyDown={e=>e.key==="Enter"&&login()} />
            </div>
            <button className="btn-primary" style={{width:"100%",marginBottom:16}} onClick={login}>Sign In</button>
            <div className="divider">or</div>
            <button className="btn-outline" style={{width:"100%"}} onClick={()=>setPage("register")}>Create Account</button>
            <p style={{fontSize:12,color:"var(--muted)",textAlign:"center",marginTop:16}}>Demo: alice@demo.com / 1234</p>
          </div>
        </div>
      )}

      {page === "register" && (
        <div className="login-page">
          <div className="login-bg" />
          <div className="login-card fade-up" style={{width:480}}>
            <div className="login-logo">SMART STORE</div>
            <div className="login-sub">Create Account</div>
            <Notification msg={msg} />
            <div className="form-group">
              <label className="form-label">Full Name *</label>
              <input className="form-input" placeholder="Your Name" value={regForm.name} onChange={e=>setRegForm({...regForm,name:e.target.value})} />
            </div>
            <div className="form-group">
              <label className="form-label">Email *</label>
              <input className="form-input" type="email" placeholder="your@email.com" value={regForm.email} onChange={e=>setRegForm({...regForm,email:e.target.value})} />
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Password *</label>
                <input className="form-input" type="password" placeholder="••••••••" value={regForm.password} onChange={e=>setRegForm({...regForm,password:e.target.value})} />
              </div>
              <div className="form-group">
                <label className="form-label">Confirm *</label>
                <input className="form-input" type="password" placeholder="••••••••" value={regForm.confirm} onChange={e=>setRegForm({...regForm,confirm:e.target.value})} />
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">Age</label>
                <input className="form-input" type="number" placeholder="25" value={regForm.age} onChange={e=>setRegForm({...regForm,age:e.target.value})} />
              </div>
              <div className="form-group">
                <label className="form-label">Gender</label>
                <select className="form-select" value={regForm.gender} onChange={e=>setRegForm({...regForm,gender:e.target.value})}>
                  <option>Female</option><option>Male</option><option>Other</option>
                </select>
              </div>
            </div>
            <button className="btn-primary" style={{width:"100%",marginBottom:16}} onClick={register}>Create Account</button>
            <button className="btn-outline" style={{width:"100%"}} onClick={()=>setPage("login")}>Back to Sign In</button>
          </div>
        </div>
      )}

      {page === "profile" && currentMember && (
        <div className="section" style={{maxWidth:640}}>
          <div className="section-title serif">My Account</div>
          <div className="section-sub">Member Profile</div>
          <div style={{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:"var(--r)",padding:32,marginBottom:24}}>
            <div style={{display:"flex",alignItems:"center",gap:20,marginBottom:28}}>
              <div style={{width:64,height:64,borderRadius:"50%",background:"rgba(201,169,110,0.15)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:24,fontFamily:"Cormorant Garamond,serif",color:"var(--gold)"}}>
                {currentMember.name[0]}
              </div>
              <div>
                <div style={{fontSize:22,fontFamily:"Cormorant Garamond,serif"}}>{currentMember.name}</div>
                <div style={{fontSize:11,letterSpacing:2,textTransform:"uppercase",color:LEVEL_COLORS[currentMember.level]||"var(--gold)"}}>{currentMember.level} Member</div>
              </div>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:16,marginBottom:24}}>
              {[
                ["Email",currentMember.email],["Member ID",currentMember.id],
                ["Age",currentMember.age],["Gender",currentMember.gender],
              ].map(([l,v])=>(
                <div key={l} style={{background:"var(--bg3)",borderRadius:"var(--r)",padding:16}}>
                  <div style={{fontSize:11,letterSpacing:2,textTransform:"uppercase",color:"var(--muted)",marginBottom:4}}>{l}</div>
                  <div style={{fontSize:14}}>{v}</div>
                </div>
              ))}
            </div>
            <div className="metrics">
              <div className="metric"><div className="metric-label">Points</div><div className="metric-value">{currentMember.point.toLocaleString()}</div></div>
              <div className="metric"><div className="metric-label">Coupons</div><div className="metric-value">{currentMember.coupon}</div></div>
              <div className="metric"><div className="metric-label">Total Spent</div><div className="metric-value" style={{fontSize:18}}>NT${currentMember.total_spending.toLocaleString()}</div></div>
            </div>
          </div>
          <button className="btn-outline" onClick={()=>setPage("shop")}>← Back to Shop</button>
        </div>
      )}

      {page === "checkout" && (
        <div className="section">
          <div className="section-title serif">Checkout</div>
          <div className="section-sub">Complete your purchase</div>
          <Notification msg={msg} />
          <div className="checkout-grid">
            <div>
              <div style={{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:"var(--r)",padding:28,marginBottom:24}}>
                <div style={{fontSize:14,fontWeight:500,marginBottom:20,letterSpacing:1}}>PAYMENT</div>
                {!currentMember && (
                  <div style={{marginBottom:20,padding:16,background:"rgba(201,169,110,0.06)",borderRadius:"var(--r)",fontSize:13,color:"var(--muted)"}}>
                    💡 <span style={{color:"var(--gold)"}}>Sign in</span> to apply member discounts and earn points.
                  </div>
                )}
                {currentMember && (
                  <div style={{marginBottom:20,padding:14,background:"rgba(201,169,110,0.08)",borderRadius:"var(--r)",fontSize:13}}>
                    ♦ Paying as <strong style={{color:"var(--gold)"}}>{currentMember.name}</strong> — {currentMember.level.toUpperCase()} discount applied
                  </div>
                )}
                <div className="form-group">
                  <label className="form-label">Payment Amount (NT$) *</label>
                  <input className="form-input" type="number" placeholder={`Minimum NT$ ${checkoutTotal.toLocaleString()}`} value={payInput} onChange={e=>setPayInput(e.target.value)} />
                </div>
                <button className="btn-primary" style={{width:"100%"}} onClick={()=>processCheckout(checkoutTotal,checkoutSub)}>
                  Confirm Payment
                </button>
              </div>
            </div>
            <div>
              <div className="order-summary">
                <div style={{fontSize:13,letterSpacing:2,textTransform:"uppercase",marginBottom:20,color:"var(--muted)"}}>Order Summary</div>
                {cart.map(item => (
                  <div className="summary-row" key={item.id}>
                    <span>{item.name} × {item.qty}</span>
                    <span>NT$ {(item.price*item.qty).toLocaleString()}</span>
                  </div>
                ))}
                {checkoutSub !== checkoutTotal && (
                  <div className="summary-row">
                    <span className="summary-label">Subtotal</span>
                    <span style={{textDecoration:"line-through",color:"var(--muted)"}}>NT$ {checkoutSub.toLocaleString()}</span>
                  </div>
                )}
                <div className="summary-row">
                  <span className="summary-label">Total</span>
                  <span>NT$ {checkoutTotal.toLocaleString()}</span>
                </div>
                <button className="btn-outline" style={{width:"100%",marginTop:16}} onClick={()=>{setPage("shop");setCartOpen(true)}}>← Edit Cart</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <CartPanel cart={cart} setCart={setCart} member={currentMember} onCheckout={startCheckout}
        open={cartOpen} onClose={()=>setCartOpen(false)} inventory={inventory} />

      {page === "shop" && (
        <footer style={{borderTop:"1px solid var(--border)",padding:"60px 40px",marginTop:60}}>
          <div style={{maxWidth:1280,margin:"0 auto",display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))",gap:40}}>
            <div>
              <div style={{fontFamily:"Cormorant Garamond,serif",fontSize:20,color:"var(--gold)",letterSpacing:2,marginBottom:16}}>SMART STORE</div>
              <p style={{fontSize:13,color:"var(--muted)",lineHeight:1.8}}>Modern retail powered by an integrated store management system.</p>
            </div>
            <div>
              <div style={{fontSize:11,letterSpacing:2,textTransform:"uppercase",color:"var(--muted)",marginBottom:16}}>Membership</div>
              {[["Bronze","No discount"],["Silver","5% off"],["Gold","10% off"],["VIP","15% off"]].map(([l,d])=>(
                <div key={l} style={{fontSize:13,color:"var(--muted)",marginBottom:8}}>
                  <span style={{color:LEVEL_COLORS[l.toLowerCase()]||"var(--gold)"}}>♦ {l}</span> — {d}
                </div>
              ))}
            </div>
            <div>
              <div style={{fontSize:11,letterSpacing:2,textTransform:"uppercase",color:"var(--muted)",marginBottom:16}}>Contact</div>
              <p style={{fontSize:13,color:"var(--muted)",lineHeight:1.8}}>Mon–Sun / 10:00–21:00<br/>smartstore@demo.com</p>
            </div>
          </div>
          <div style={{borderTop:"1px solid var(--border)",marginTop:40,paddingTop:20,textAlign:"center",fontSize:12,color:"var(--muted)"}}>
            © 2026 Smart Store System. All rights reserved.
          </div>
        </footer>
      )}
    </div>
  );
}

// ─── WORKER VIEW ───────────────────────────────────────────────

function WorkerView({ inventory, setInventory, salaries, setSalaries }) {
  const [loggedIn, setLoggedIn] = useState(false);
  const [workerId, setWorkerId] = useState("");
  const [workerData, setWorkerData] = useState(null);
  const [page, setPage] = useState("login");
  const [msg, setMsg] = useState(null);
  const [addHours, setAddHours] = useState("");
  const [newBonus, setNewBonus] = useState("");
  const [newDeduct, setNewDeduct] = useState("");
  const [newItem, setNewItem] = useState({name:"",price:"",stock:"",category:"Electronics"});

  function login() {
    const w = salaries.find(s => s.worker_id === workerId);
    if (w) {
      setWorkerData(w);
      setLoggedIn(true);
      setPage("dashboard");
    } else {
      setMsg({type:"error",text:"Worker ID not found."});
    }
  }

  function updateHours() {
    const h = parseFloat(addHours);
    if (isNaN(h) || h <= 0) return setMsg({type:"error",text:"Please enter valid hours."});
    setSalaries(salaries.map(s => s.worker_id === workerData.worker_id ? {...s, hours_worked: s.hours_worked+h} : s));
    setWorkerData({...workerData, hours_worked: workerData.hours_worked+h});
    setAddHours("");
    setMsg({type:"success",text:`Added ${h} hours. Total: ${workerData.hours_worked+h}h`});
  }

  function addInventoryItem() {
    if (!newItem.name || !newItem.price || !newItem.stock) return setMsg({type:"error",text:"Fill all fields."});
    const item = {
      id:`P${String(inventory.length+1).padStart(3,"0")}`,
      name:newItem.name, price:parseFloat(newItem.price), stock:parseInt(newItem.stock),
      category:newItem.category
    };
    setInventory([...inventory, item]);
    setNewItem({name:"",price:"",stock:"",category:"Electronics"});
    setMsg({type:"success",text:`Added "${item.name}" to inventory.`});
  }

  if (!loggedIn) return (
    <div>
      <style>{FONT_STYLES}{CSS}</style>
      <div className="login-page">
        <div className="login-bg" />
        <div className="login-card fade-up">
          <div className="login-logo">SMART STORE</div>
          <div className="login-sub">Worker Portal</div>
          <Notification msg={msg} />
          <div className="form-group">
            <label className="form-label">Worker ID</label>
            <input className="form-input" placeholder="e.g. W001" value={workerId} onChange={e=>setWorkerId(e.target.value)} onKeyDown={e=>e.key==="Enter"&&login()} />
          </div>
          <button className="btn-primary" style={{width:"100%"}} onClick={login}>Access Worker Portal</button>
          <p style={{fontSize:12,color:"var(--muted)",textAlign:"center",marginTop:16}}>Demo IDs: W001, W002, W003</p>
        </div>
      </div>
    </div>
  );

  const netSalary = workerData.base_salary + workerData.bonus - workerData.deductions;

  return (
    <div>
      <style>{FONT_STYLES}{CSS}</style>
      <div className="dash">
        <div className="dash-sidebar">
          <div className="dash-logo">WORKER</div>
          <div className="dash-menu-section">Navigation</div>
          {[["dashboard","Dashboard"],["inventory","Inventory"],["salary","My Salary"]].map(([k,l])=>(
            <div key={k} className={`dash-menu-item ${page===k?"active":""}`} onClick={()=>{setPage(k);setMsg(null)}}>{l}</div>
          ))}
          <div style={{marginTop:"auto",borderTop:"1px solid var(--border)",paddingTop:16,marginTop:200}}>
            <div className="dash-menu-item" onClick={()=>{setLoggedIn(false);setWorkerData(null);setPage("login");}}>
              Sign Out
            </div>
          </div>
        </div>
        <div className="dash-content">
          <div className="dash-header">
            <div className="dash-title serif">{page === "dashboard" ? `Welcome, ${workerData.worker_name}` : page === "inventory" ? "Inventory Management" : "My Salary"}</div>
            <div className="dash-sub">{workerData.worker_id} · {workerData.worker_role}</div>
          </div>

          <Notification msg={msg} />

          {page === "dashboard" && (
            <>
              <div className="metrics">
                <div className="metric"><div className="metric-label">Base Salary</div><div className="metric-value" style={{fontSize:20}}>NT${workerData.base_salary.toLocaleString()}</div></div>
                <div className="metric"><div className="metric-label">Hours Worked</div><div className="metric-value">{workerData.hours_worked}h</div></div>
                <div className="metric"><div className="metric-label">Net Salary</div><div className="metric-value" style={{fontSize:20,color:"var(--green)"}}>NT${netSalary.toLocaleString()}</div></div>
              </div>
              <div style={{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:"var(--r)",padding:24,marginBottom:24}}>
                <div style={{fontSize:13,letterSpacing:2,textTransform:"uppercase",color:"var(--muted)",marginBottom:16}}>Log Work Hours</div>
                <div style={{display:"flex",gap:12,alignItems:"flex-end"}}>
                  <div style={{flex:1}}>
                    <label className="form-label">Hours to Add</label>
                    <input className="form-input" type="number" placeholder="e.g. 8" value={addHours} onChange={e=>setAddHours(e.target.value)} />
                  </div>
                  <button className="btn-primary" onClick={updateHours}>Log Hours</button>
                </div>
              </div>
            </>
          )}

          {page === "inventory" && (
            <>
              <div style={{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:"var(--r)",padding:24,marginBottom:32}}>
                <div style={{fontSize:13,letterSpacing:2,textTransform:"uppercase",color:"var(--muted)",marginBottom:20}}>Add New Item</div>
                <div className="form-row">
                  <div className="form-group"><label className="form-label">Item Name</label><input className="form-input" value={newItem.name} onChange={e=>setNewItem({...newItem,name:e.target.value})} /></div>
                  <div className="form-group"><label className="form-label">Category</label>
                    <select className="form-select" value={newItem.category} onChange={e=>setNewItem({...newItem,category:e.target.value})}>
                      {Object.keys(ITEM_ICONS).filter(k=>k!=="Default").map(c=><option key={c}>{c}</option>)}
                    </select>
                  </div>
                </div>
                <div className="form-row">
                  <div className="form-group"><label className="form-label">Price (NT$)</label><input className="form-input" type="number" value={newItem.price} onChange={e=>setNewItem({...newItem,price:e.target.value})} /></div>
                  <div className="form-group"><label className="form-label">Stock Qty</label><input className="form-input" type="number" value={newItem.stock} onChange={e=>setNewItem({...newItem,stock:e.target.value})} /></div>
                </div>
                <button className="btn-primary" onClick={addInventoryItem}>Add Item</button>
              </div>
              <div className="table-wrap">
                <table>
                  <thead><tr><th>ID</th><th>Item</th><th>Category</th><th>Price</th><th>Stock</th></tr></thead>
                  <tbody>
                    {inventory.map(item => (
                      <tr key={item.id}>
                        <td style={{fontFamily:"DM Mono,monospace",fontSize:12,color:"var(--muted)"}}>{item.id}</td>
                        <td>{getIcon(item.category)} {item.name}</td>
                        <td style={{color:"var(--muted)",fontSize:12}}>{item.category}</td>
                        <td style={{fontFamily:"DM Mono,monospace",color:"var(--gold)"}}>NT$ {item.price.toLocaleString()}</td>
                        <td><span style={{color:item.stock<=5?"var(--red)":item.stock<=10?"#e6a817":"var(--green)",fontFamily:"DM Mono,monospace"}}>{item.stock}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}

          {page === "salary" && (
            <div style={{maxWidth:560}}>
              <div style={{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:"var(--r)",padding:28,marginBottom:24}}>
                {[["Worker ID",workerData.worker_id],["Name",workerData.worker_name],["Role",workerData.worker_role]].map(([l,v])=>(
                  <div key={l} style={{display:"flex",justifyContent:"space-between",padding:"12px 0",borderBottom:"1px solid var(--border)"}}>
                    <span style={{color:"var(--muted)",fontSize:13}}>{l}</span><span style={{fontSize:13}}>{v}</span>
                  </div>
                ))}
                {[["Base Salary",`NT$ ${workerData.base_salary.toLocaleString()}`],["Hours Worked",`${workerData.hours_worked}h`],["Bonus",`+NT$ ${workerData.bonus.toLocaleString()}`],["Deductions",`−NT$ ${workerData.deductions.toLocaleString()}`]].map(([l,v])=>(
                  <div key={l} style={{display:"flex",justifyContent:"space-between",padding:"12px 0",borderBottom:"1px solid var(--border)"}}>
                    <span style={{color:"var(--muted)",fontSize:13}}>{l}</span><span style={{fontFamily:"DM Mono,monospace",fontSize:13}}>{v}</span>
                  </div>
                ))}
                <div style={{display:"flex",justifyContent:"space-between",padding:"16px 0",marginTop:4}}>
                  <span style={{fontWeight:500,letterSpacing:1}}>Net Salary</span>
                  <span style={{fontFamily:"DM Mono,monospace",fontSize:20,color:"var(--green)"}}>NT$ {netSalary.toLocaleString()}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── OWNER VIEW ────────────────────────────────────────────────

function OwnerView({ members, inventory, transactions, setTransactions, salaries, setSalaries, setInventory }) {
  const [loggedIn, setLoggedIn] = useState(false);
  const [user, setUser] = useState("");
  const [pw, setPw] = useState("");
  const [page, setPage] = useState("overview");
  const [msg, setMsg] = useState(null);
  const [newWorker, setNewWorker] = useState({worker_id:"",worker_name:"",worker_role:"",base_salary:""});
  const [expDesc, setExpDesc] = useState("");
  const [expAmt, setExpAmt] = useState("");

  const balance = calcBalance(transactions);
  const revenue = transactions.filter(t=>t.amount>0).reduce((s,t)=>s+t.amount,0);
  const expense = transactions.filter(t=>t.amount<0).reduce((s,t)=>s+Math.abs(t.amount),0);

  function login() {
    if (user === "admin" && pw === "admin") { setLoggedIn(true); setPage("overview"); }
    else setMsg({type:"error",text:"Invalid credentials."});
  }

  function addExpense() {
    if (!expDesc || !expAmt || isNaN(parseFloat(expAmt))) return setMsg({type:"error",text:"Fill in description and amount."});
    const t = {
      id:`T${String(transactions.length+1).padStart(4,"0")}`,
      type:"expense", amount:-Math.abs(parseFloat(expAmt)),
      description:expDesc, date: new Date().toLocaleString("sv-SE").replace("T"," ")
    };
    setTransactions([...transactions, t]);
    setExpDesc(""); setExpAmt("");
    setMsg({type:"success",text:"Expense recorded."});
  }

  function createWorker() {
    if (!newWorker.worker_id || !newWorker.worker_name || !newWorker.base_salary) return setMsg({type:"error",text:"Fill required fields."});
    if (salaries.find(s => s.worker_id === newWorker.worker_id)) return setMsg({type:"error",text:"Worker ID already exists."});
    const w = { ...newWorker, base_salary:parseFloat(newWorker.base_salary), hours_worked:0, bonus:0, deductions:0 };
    setSalaries([...salaries, w]);
    setNewWorker({worker_id:"",worker_name:"",worker_role:"",base_salary:""});
    setMsg({type:"success",text:`Worker ${w.worker_name} added.`});
  }

  function paySalary(worker) {
    const net = worker.base_salary + worker.bonus - worker.deductions;
    const t = {
      id:`T${String(transactions.length+1).padStart(4,"0")}`,
      type:"expense", amount:-net,
      description:`Salary Payment — ${worker.worker_name} (${worker.worker_id})`,
      date: new Date().toLocaleString("sv-SE").replace("T"," ")
    };
    setTransactions(prev => [...prev, t]);
    setSalaries(salaries.map(s => s.worker_id === worker.worker_id ? {...s, bonus:0, hours_worked:0} : s));
    setMsg({type:"success",text:`Paid NT$${net.toLocaleString()} to ${worker.worker_name}.`});
  }

  if (!loggedIn) return (
    <div>
      <style>{FONT_STYLES}{CSS}</style>
      <div className="login-page">
        <div className="login-bg" />
        <div className="login-card fade-up">
          <div className="login-logo">SMART STORE</div>
          <div className="login-sub">Owner Dashboard</div>
          <Notification msg={msg} />
          <div className="form-group"><label className="form-label">Username</label><input className="form-input" value={user} onChange={e=>setUser(e.target.value)} /></div>
          <div className="form-group"><label className="form-label">Password</label><input className="form-input" type="password" value={pw} onChange={e=>setPw(e.target.value)} onKeyDown={e=>e.key==="Enter"&&login()} /></div>
          <button className="btn-primary" style={{width:"100%"}} onClick={login}>Sign In as Owner</button>
          <p style={{fontSize:12,color:"var(--muted)",textAlign:"center",marginTop:16}}>admin / admin</p>
        </div>
      </div>
    </div>
  );

  const navItems = [["overview","Overview"],["transactions","Transactions"],["members","Members"],["inventory","Inventory"],["salary","Salary"]];

  return (
    <div>
      <style>{FONT_STYLES}{CSS}</style>
      <div className="dash">
        <div className="dash-sidebar">
          <div className="dash-logo">OWNER</div>
          <div className="dash-menu-section">Management</div>
          {navItems.map(([k,l])=>(
            <div key={k} className={`dash-menu-item ${page===k?"active":""}`} onClick={()=>{setPage(k);setMsg(null)}}>{l}</div>
          ))}
          <div style={{marginTop:200,borderTop:"1px solid var(--border)",paddingTop:16}}>
            <div className="dash-menu-item" onClick={()=>setLoggedIn(false)}>Sign Out</div>
          </div>
        </div>

        <div className="dash-content">
          <div className="dash-header">
            <div className="dash-title serif">
              {{overview:"Store Overview",transactions:"Transactions",members:"Member Management",inventory:"Inventory",salary:"Salary Management"}[page]}
            </div>
            <div className="dash-sub">Smart Store System · Owner Console</div>
          </div>

          <Notification msg={msg} />

          {page === "overview" && (
            <>
              <div className="metrics">
                <div className="metric"><div className="metric-label">Balance</div><div className="metric-value" style={{color:balance>=0?"var(--green)":"var(--red)",fontSize:22}}>NT${balance.toLocaleString()}</div></div>
                <div className="metric"><div className="metric-label">Total Revenue</div><div className="metric-value" style={{fontSize:20}}>NT${revenue.toLocaleString()}</div></div>
                <div className="metric"><div className="metric-label">Total Expense</div><div className="metric-value" style={{fontSize:20,color:"var(--red)"}}>NT${expense.toLocaleString()}</div></div>
                <div className="metric"><div className="metric-label">Members</div><div className="metric-value">{members.length}</div></div>
                <div className="metric"><div className="metric-label">Products</div><div className="metric-value">{inventory.length}</div></div>
                <div className="metric"><div className="metric-label">Workers</div><div className="metric-value">{salaries.length}</div></div>
              </div>
              <div style={{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:"var(--r)",padding:24}}>
                <div style={{fontSize:13,letterSpacing:2,textTransform:"uppercase",color:"var(--muted)",marginBottom:16}}>Record Expense</div>
                <div style={{display:"flex",gap:12,flexWrap:"wrap",alignItems:"flex-end"}}>
                  <div style={{flex:2,minWidth:200}}>
                    <label className="form-label">Description</label>
                    <input className="form-input" placeholder="e.g. Store Rent" value={expDesc} onChange={e=>setExpDesc(e.target.value)} />
                  </div>
                  <div style={{flex:1,minWidth:140}}>
                    <label className="form-label">Amount (NT$)</label>
                    <input className="form-input" type="number" placeholder="0" value={expAmt} onChange={e=>setExpAmt(e.target.value)} />
                  </div>
                  <button className="btn-primary" onClick={addExpense}>Record</button>
                </div>
              </div>
            </>
          )}

          {page === "transactions" && (
            <div className="table-wrap">
              <table>
                <thead><tr><th>ID</th><th>Date</th><th>Type</th><th>Amount</th><th>Detail</th></tr></thead>
                <tbody>
                  {[...transactions].reverse().map(t=>(
                    <tr key={t.id}>
                      <td style={{fontFamily:"DM Mono,monospace",fontSize:11,color:"var(--muted)"}}>{t.id}</td>
                      <td style={{fontSize:12,color:"var(--muted)"}}>{t.date}</td>
                      <td><span className={`tag ${t.amount>0?"revenue":"expense"}`}>{t.type}</span></td>
                      <td style={{fontFamily:"DM Mono,monospace",color:t.amount>0?"var(--green)":"var(--red)"}}>
                        {t.amount>0?"+":""}NT${Math.abs(t.amount).toLocaleString()}
                      </td>
                      <td style={{fontSize:12,color:"var(--muted)"}}>
                        {t.description || (t.items ? t.items.map(i=>`${i.name}×${i.qty||i.quantity}`).join(", ") : "—")}
                        {t.member_id && <span style={{color:"var(--gold)",marginLeft:6}}>#{t.member_id}</span>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {page === "members" && (
            <div className="table-wrap">
              <table>
                <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Level</th><th>Points</th><th>Coupons</th><th>Total Spent</th></tr></thead>
                <tbody>
                  {members.map(m=>(
                    <tr key={m.id}>
                      <td style={{fontFamily:"DM Mono,monospace",fontSize:11,color:"var(--muted)"}}>{m.id}</td>
                      <td>{m.name}</td>
                      <td style={{fontSize:12,color:"var(--muted)"}}>{m.email}</td>
                      <td><span style={{fontSize:11,letterSpacing:1,textTransform:"uppercase",color:LEVEL_COLORS[m.level]||"var(--gold)"}}>{m.level}</span></td>
                      <td style={{fontFamily:"DM Mono,monospace"}}>{m.point}</td>
                      <td style={{fontFamily:"DM Mono,monospace"}}>{m.coupon}</td>
                      <td style={{fontFamily:"DM Mono,monospace",color:"var(--gold)"}}>NT${m.total_spending.toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {page === "inventory" && (
            <div className="table-wrap">
              <table>
                <thead><tr><th>ID</th><th>Item</th><th>Category</th><th>Price</th><th>Stock</th><th>Value</th></tr></thead>
                <tbody>
                  {inventory.map(item=>(
                    <tr key={item.id}>
                      <td style={{fontFamily:"DM Mono,monospace",fontSize:11,color:"var(--muted)"}}>{item.id}</td>
                      <td>{getIcon(item.category)} {item.name}</td>
                      <td style={{fontSize:12,color:"var(--muted)"}}>{item.category}</td>
                      <td style={{fontFamily:"DM Mono,monospace",color:"var(--gold)"}}>NT${item.price.toLocaleString()}</td>
                      <td style={{fontFamily:"DM Mono,monospace",color:item.stock<=5?"var(--red)":item.stock<=10?"#e6a817":"var(--green)"}}>{item.stock}</td>
                      <td style={{fontFamily:"DM Mono,monospace",fontSize:12,color:"var(--muted)"}}>NT${(item.price*item.stock).toLocaleString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {page === "salary" && (
            <>
              <div style={{background:"var(--bg2)",border:"1px solid var(--border)",borderRadius:"var(--r)",padding:24,marginBottom:32}}>
                <div style={{fontSize:13,letterSpacing:2,textTransform:"uppercase",color:"var(--muted)",marginBottom:20}}>Add New Worker</div>
                <div className="form-row">
                  <div className="form-group"><label className="form-label">Worker ID *</label><input className="form-input" placeholder="W004" value={newWorker.worker_id} onChange={e=>setNewWorker({...newWorker,worker_id:e.target.value})} /></div>
                  <div className="form-group"><label className="form-label">Full Name *</label><input className="form-input" value={newWorker.worker_name} onChange={e=>setNewWorker({...newWorker,worker_name:e.target.value})} /></div>
                </div>
                <div className="form-row">
                  <div className="form-group"><label className="form-label">Role</label><input className="form-input" placeholder="Cashier" value={newWorker.worker_role} onChange={e=>setNewWorker({...newWorker,worker_role:e.target.value})} /></div>
                  <div className="form-group"><label className="form-label">Base Salary (NT$) *</label><input className="form-input" type="number" value={newWorker.base_salary} onChange={e=>setNewWorker({...newWorker,base_salary:e.target.value})} /></div>
                </div>
                <button className="btn-primary" onClick={createWorker}>Add Worker</button>
              </div>
              <div className="table-wrap">
                <table>
                  <thead><tr><th>ID</th><th>Name</th><th>Role</th><th>Base</th><th>Hours</th><th>Bonus</th><th>Deductions</th><th>Net</th><th></th></tr></thead>
                  <tbody>
                    {salaries.map(w=>{
                      const net = w.base_salary+w.bonus-w.deductions;
                      return (
                        <tr key={w.worker_id}>
                          <td style={{fontFamily:"DM Mono,monospace",fontSize:11,color:"var(--muted)"}}>{w.worker_id}</td>
                          <td>{w.worker_name}</td>
                          <td style={{fontSize:12,color:"var(--muted)"}}>{w.worker_role}</td>
                          <td style={{fontFamily:"DM Mono,monospace",fontSize:12}}>NT${w.base_salary.toLocaleString()}</td>
                          <td style={{fontFamily:"DM Mono,monospace"}}>{w.hours_worked}h</td>
                          <td style={{fontFamily:"DM Mono,monospace",color:"var(--green)"}}>+{w.bonus.toLocaleString()}</td>
                          <td style={{fontFamily:"DM Mono,monospace",color:"var(--red)"}}>-{w.deductions.toLocaleString()}</td>
                          <td style={{fontFamily:"DM Mono,monospace",color:"var(--gold)",fontWeight:500}}>NT${net.toLocaleString()}</td>
                          <td><button onClick={()=>paySalary(w)} style={{fontSize:11,letterSpacing:1,background:"var(--bg4)",border:"1px solid var(--border)",color:"var(--text)",padding:"6px 14px",cursor:"pointer",borderRadius:4}}>Pay</button></td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── ROOT APP ──────────────────────────────────────────────────

export default function App() {
  const [role, setRole] = useState("customer");
  const [members, setMembers] = useState(INITIAL_MEMBERS);
  const [inventory, setInventory] = useState(INITIAL_INVENTORY);
  const [transactions, setTransactions] = useState(INITIAL_TRANSACTIONS);
  const [salaries, setSalaries] = useState(INITIAL_SALARIES);

  const shared = { members, setMembers, inventory, setInventory, transactions, setTransactions, salaries, setSalaries };

  return (
    <div>
      {role === "customer" && <CustomerView {...shared} />}
      {role === "worker" && <WorkerView inventory={inventory} setInventory={setInventory} salaries={salaries} setSalaries={setSalaries} />}
      {role === "owner" && <OwnerView {...shared} />}

      {/* Role Switcher */}
      <div className="role-switcher">
        {[["customer","🛍 Customer"],["worker","⚙ Worker"],["owner","👔 Owner"]].map(([r,l])=>(
          <button key={r} className={`role-btn ${role===r?"active":""}`} onClick={()=>setRole(r)}>{l}</button>
        ))}
      </div>
    </div>
  );
}
